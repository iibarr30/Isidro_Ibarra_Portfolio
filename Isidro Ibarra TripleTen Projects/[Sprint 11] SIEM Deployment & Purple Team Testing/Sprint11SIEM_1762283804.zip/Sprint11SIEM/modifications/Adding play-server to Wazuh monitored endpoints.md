---
entity type:
  - modification
device: play-server
changelogs: 2025-10-23 at 10-34-05
description: Adding testing server to be monitored
---
# Overview
> [!tip]- I will be adding device [play-server] as an agent to our Wazuh’s monitored endpoints. The reason why is to test how attacks would differ from two Linux devices 
> Be sure to include details like **what the modification is** and **why you want to make it**.



# TODO
> [!tip]- List the steps involved in implementing and testing this modification.
> Indent this checklist to keep tasks hierarchically organized. Try to break all the steps down into the smallest chunks possible so that it's easy to track and annotate your progress.

- [x] ADD AN AGENT ENTRY IN WAZUH
- [x] COPY THE INSTALL PACKAGE
- [x] LOGIN INTO play-server
	- [x] GET INTO ROOT DIRECTORY
	- [x] PASTE THE INSTALL PACKAGE INTO THE SHELL
	- [x] ENABLE THE AGENT
	- [x] VERIFY IF IT WORKED
- [x] CHECK ON WAZUH WEBSITE IF IT IS ONLINE


# References
> [!tip] List any external [[References]] you're using to figure out how to implement and test this modification.

- [ ] https://medium.com/@rishavkumarthapa/day-26-setting-up-wazuh-for-endpoint-detection-and-response-edr-a-beginners-guide-4277d4707052

# Involved devices
> [!tip]- List any [[Devices]] you will need to access while implementing this modification.
> Be clear what role each device you list plays in implementing this modification.

- [[play-server]] 
- [[Blue-Team Workstation]]
# Involved files
> [!tip] List any [[files]] you will need to modify or create while implementing this modification.

- 
- 

> [!success] Use the **Linked mentions** section below to discover all other entries that are somehow related to this modification.