---
entity type:
  - mistake
date: 2025-10-24T13:50:54
description: Couldn't connect to play server using sess command
---
# Related changelogs
> [!tip] Link to any [[changelogs]] related to what you were doing when you realized you made a mistake *or* corrected it.

- [[2025-10-27 at 9-00-10]]

# 🤔 What I thought was true
> [!tip] What was your original assumption or mental model? What did you expect to happen, and why did that seem reasonable at the time? This helps show your initial line of thinking.

I thought that using the sess command normally would connect with the play-server


# 😬 What actually happened
> [!tip] Describe the reality you ran into. What broke, what didn’t work, or what confused you? Don’t hold back — be honest about the moment things went sideways.

The command didn't work and gave an error




# 💡 What I realized
> [!tip] This is the “aha!” moment. What did you discover or figure out? If this was a misunderstanding, what was the subtle detail you were missing? Try to explain it in your own words.

The command only worked before is because it was connecting to a Window device while I'm trying to connect to a Linux. 


# 🔧 How I fixed it (or plan to fix it)
> [!tip] Outline the steps you took — or are going to take — to correct the issue. Be as specific as possible. Screenshots, commands, logs, or configs are welcome here.

Using a different flag (which required using an updated PowerShell) in the command [-Hostname] [-Username]


# 🔁 How I might avoid this in the future
> [!tip] What safeguards, habits, or mental checks might help you catch this earlier next time? Would a checklist, alert, or log pattern clue you in faster? This helps turn the mistake into long-term wisdom.

To read the documentation first before doing any test


# 🔎 How this shifted my understanding
> [!tip] Step back for a second. Did this mistake change how you think about the system or tool? Did it reveal something deeper about how logging, parsing, or detection really works?

This mistake showed me that they are more steps to take for doing test remotely on different OS.


# 📚 Helpful resources
> [!tip] Link to any documentation, blog posts, videos, GitHub issues, or forum threads that helped you troubleshoot or understand the problem. Bonus points if you jot down what was helpful about each one.

https://www.atomicredteam.io/invoke-atomicredteam/docs/execute-tests-remotely


# 🗒️ Notes to my future self
> [!tip] Pretend you’re leaving a Post-it for the next time you’re in this situation — or for a teammate asking you for help. What would you want someone else to know if they hit this same wall?

To read the documentation