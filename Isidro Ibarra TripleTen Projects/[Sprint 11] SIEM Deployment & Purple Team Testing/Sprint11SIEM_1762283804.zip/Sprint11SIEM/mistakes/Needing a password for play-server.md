---
entity type:
  - mistake
date: 2025-10-25T10:32:41
description: connecting to play-server required a password that I don't know
---
# Related changelogs
> [!tip] Link to any [[changelogs]] related to what you were doing when you realized you made a mistake *or* corrected it.

- [[2025-10-27 at 9-00-10]]

# 🤔 What I thought was true
> [!tip] What was your original assumption or mental model? What did you expect to happen, and why did that seem reasonable at the time? This helps show your initial line of thinking.

Using the correct sess command would let me automatically connect to the play-server


# 😬 What actually happened
> [!tip] Describe the reality you ran into. What broke, what didn’t work, or what confused you? Don’t hold back — be honest about the moment things went sideways.

It gave me a prompt to enter a password I didn't know




# 💡 What I realized
> [!tip] This is the “aha!” moment. What did you discover or figure out? If this was a misunderstanding, what was the subtle detail you were missing? Try to explain it in your own words.

I need to change the password within play-server, enable SSH on play-server, and config the file to allow a connection


# 🔧 How I fixed it (or plan to fix it)
> [!tip] Outline the steps you took — or are going to take — to correct the issue. Be as specific as possible. Screenshots, commands, logs, or configs are welcome here.

Install [sudo apt install openssh-client] and [sudo apt install openssh-server]
Used [sudo passwd sysadmin] to change password to [Triple10.]
Change a line in [sshd_config] file to allow connection

![[T1003-008_connection.png]]

![[T1003-008_fix.png]]
# 🔁 How I might avoid this in the future
> [!tip] What safeguards, habits, or mental checks might help you catch this earlier next time? Would a checklist, alert, or log pattern clue you in faster? This helps turn the mistake into long-term wisdom.

#ADD-YOUR-OWN-ANSWER-HERE


# 🔎 How this shifted my understanding
> [!tip] Step back for a second. Did this mistake change how you think about the system or tool? Did it reveal something deeper about how logging, parsing, or detection really works?

#ADD-YOUR-OWN-ANSWER-HERE


# 📚 Helpful resources
> [!tip] Link to any documentation, blog posts, videos, GitHub issues, or forum threads that helped you troubleshoot or understand the problem. Bonus points if you jot down what was helpful about each one.

https://learn.microsoft.com/en-us/powershell/scripting/security/remoting/ssh-remoting-in-powershell?view=powershell-7.5

https://askubuntu.com/questions/497895/permission-denied-for-rootlocalhost-for-ssh-connection


# 🗒️ Notes to my future self
> [!tip] Pretend you’re leaving a Post-it for the next time you’re in this situation — or for a teammate asking you for help. What would you want someone else to know if they hit this same wall?

#ADD-YOUR-OWN-ANSWER-HERE