Use this TODO List to track your progress towards completing your project.


## Preparation
> [!tip] This is all about deciding what project you will undertake.
- [x] **Fill out the [[Plan Proposal]] document according to the instructions** *(in the "Devising a plan for enhancing the existing SIEM setup" task in TripleTen's courseware).*
	- [x] Discuss your [[Plan Proposal]] with an expert tutor. *(Cf. task "Consulting with an expert tutor to refine your plan")*
	- [x] Make revisions to [[Plan Proposal]] as needed after discussion with expert tutor. *(Cf. task "Consulting with an expert tutor to refine your plan")*
	- [x] Submit your plan proposal for review *(Cf. task "Get your plan approved")*
	- [x] Apply revisions as needed until [[Plan Proposal]] is approved.

> [!tip] This is all about chunking your approved plan into a discrete sequence of tasks.
- [ ] **Add your approved plan to [[The Plan]] document**
	- [x] Fill out a separate [[Modifications template]] for each planned modification
		- [x] [[Adding play-server to Wazuh monitored endpoints]]
	- [ ] Fill out a separate [[Experiment template]] for each experiment you plan to execute
		- [x] [[T1055.011 -- Process Injection - Extra Window Memory Injection]]
		- [x] [[T1003.008 - OS Credential Dumping]]
		- [x] [[T1222.002 -- File and Directory Permissions Modification - FreeBSD, Linux and Mac File and Directory Permissions Modification]]


## Implementation
> [!tip] This is all about recording the necessary information about what you're doing to be able to write a blog about it later.
- [x] **Log all changes**
	- [x] Fill out a separate [[Changelog|changelog entry]] for each major change you make while implementing your [[The Plan]]
- [x] **Track your mistakes**
	- [x] Fill out a separate [[Mistakes|mistake entry]] for each significant mistake you make


## Analysis
> [!tip] This is all about deciding which details to include in your story.
- [ ] Choose which [[Mistakes]] to highlight
- [ ] Decide which [[Changelog]] entries (associated with each [[Modifications|modification]] and [[Experiments|experiment]]) are essential to include in your blogpost — what do you need to include to tell a coherent story? *See the [[Chosen Changelogs]] note for more information.*


## Documentation
> [!tip] This is all about converting your Obsidian notes into a coherent blog post.
- [ ] **Write your first draft of each section of your blog post (using [[Blog 1. My Segmented Blog Draft (No 1)]] as a guide):**
	- [ ] [[1. Introduction]]
	- [ ] [[2. Setup]]
	- [ ] [[3. Experiment time!]]
	- [ ] [[4. Conclusion]]
	- [ ] [[5. Final thoughts]]
	- [ ] [[6. References]]
- [ ] **Concatenate your draft together into a single Markdown document:** [[Blog 2. My Unified Blog Draft (No 2)]]

## Copyediting
> [!tip] This is all about making your blog post polished enough to publish.
- [ ] Copy the contents of [[Blog 2. My Unified Blog Draft (No 2)]] into [[Deploying Wazuh SIEM - Three Atomic Tests and What I Learned]].
- [ ] Proofread your [[Deploying Wazuh SIEM - Three Atomic Tests and What I Learned|Draft 3]] with an online grammar-checking tool, making changes as needed (using [LanguageTool](https://languagetool.org), [QuillBot Grammar Checker](https://quillbot.com/grammar-check), or [Sapling Grammar Checker](https://sapling.ai/grammar-check))
- [ ] Proofread your blog draft for flow by reading it out loud; make additional edits as needed
- [ ] (OPTIONAL) Ask a friend or family member to review your post — does it sound like *you, with your personal voice?* Add changes as needed.


## Submit for expert review
- [ ] Submit for your blog post for expert review! 🎉
- [ ] Revise as needed until blog post is accepted.