---
entity type:
  - reference
title: Powershell documentation
URL: https://learn.microsoft.com/en-us/powershell
published date: 2025-07-07
author:
author affiliation:
description: "This site contains cmdlet reference for the following versions of PowerShell: 7.6, 7.5, 7.4, and 5"
blog blurb:
reference type:
  - website
date added: 2025-10-30T14-23-58
---

# Overview
> [!tip]- Describe this resource in brief.
> What do you want to remember about why you saved this resource? Record it here.

#ADD-YOUR-OWN-ANSWER-HERE 


# How did you find this?
> [!tip]- Record briefly where you ran into this resource. 
> Was it a Google search, a link on another post, social media...? Keep track of where you found this so you can tell the story accurately.

linked with Atomic Red Team documentation for remote using SSH 


# Related pages
> [!tip]- Link any related notes in this Obsidian notebook to this reference.
> You can also link directly to this note within any other note in the vault. This'll help create backlinks to make it easier to track down where you used this reference during your process.

-  [[Failing to connect to play-server]]


# Quotes
> [!tip] Record any information you might want to quote later from this external resource.

## Quote 1
> [!quote]
> ADD YOUR QUOTATION HERE

## Quote 2
> [!quote]
> ADD YOUR QUOTATION HERE

# Questions
> [!tip]- Sometimes external resources make you ask questions about the material — like "What does this term mean?" or "Why wouldn't people just...?". 
> Use this section to keep track of any questions this resource inspired you to ask. These can be great to track, *especially* if you don't have the time right now to answer those questions!

- #ADD-YOUR-OWN-ANSWER-HERE 


# Notes
> [!tip] Any miscellaneous notes you want to keep about this resource can go into this section.

#ADD-YOUR-OWN-ANSWER-HERE 