Eventually you will be ready to decide which changelog entries are valuable to reference in some way in your blog post.
> [!tip]- Check the `Include in blog?` checkbox for each changelog entry you wish to include details from.
> ![[Obsidian - Changelog - Include in blog checkbox annot.png]]

All changelog entries with the checkbox checked will appear in the below table.

```dataviewjs
function formatDate(dateStr) {
  const d = new Date(dateStr);
  if (isNaN(d)) return "";
  const pad = (n) => n.toString().padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} @ ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
}

function wrapText(content, maxWidthPx) {
  const text = Array.isArray(content) ? content.join(", ") : (content ?? "");
  return `<div style="max-width: ${maxWidthPx}px; word-wrap: break-word; white-space: normal;">${text}</div>`;
}

function wrapLink(linkObj, maxWidthPx) {
  return linkObj
    ? `<span style="max-width: ${maxWidthPx}px; display: inline-block; word-wrap: break-word; white-space: normal;">${linkObj}</span>`
    : "";
}

dv.table(
  ["Change", "Date", "Type", "Device", "Description"],
  dv.pages()
    .where(p => p["entity type"] && p["entity type"].includes("changelog") && p["include in blog?"] === true)
    .sort(p => p.date, "asc")
    .map(p => [
      wrapLink(p.file.link, 150),             // Note
      p.date ? wrapText(formatDate(p.date), 100) : "", // Date (wrapped)
      wrapText(p["change type"], 215),        // Type
      wrapText(p.device, 150),                // Device
      p.description ?? ""                     // Description
    ])
);
```