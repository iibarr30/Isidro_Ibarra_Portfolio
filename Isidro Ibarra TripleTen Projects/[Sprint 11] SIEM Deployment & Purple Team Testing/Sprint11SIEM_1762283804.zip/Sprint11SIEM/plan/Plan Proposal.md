> [!error] The template for drafting the Plan Proposal you will submit is located at [[Sprint 11] Plan Proposal {TEMPLATE}](https://docs.google.com/document/d/1YucMFQkxTsEOUkATCz_tSyeSLmLPpq3MiQVyEALLKRg/copy).
> After your **Plan Proposal** document has been approved by an expert reviewer, *then* you should paste the relevant content into this document. After that, you can use this to fill out the [[Modifications]] and [[Experiments]] notes. Then add the TODOs from those notes into the [[The Plan]] document.

---
# Modifications to environment
### Modification #1
== Adding wazuh-siem to Wazuh’s monitored endpoints == 

#### References to use while implementing
- [x] ADD
- [x] REFERENCE

**https://medium.com/@rishavkumarthapa/day-26-setting-up-wazuh-for-endpoint-detection-and-response-edr-a-beginners-guide-4277d4707052**

---

# Experiments to run
### Experiment #1
==T1055.011 - Process Injection: Extra Window Memory Injection==

#### References to use while conducting
- [ ] ADD
- [x] REFERENCE
**https://github.com/redcanaryco/atomic-red-team/blob/master/atomics/T1055.011/T1055.011.md**
--- 
### Experiment #2
==T1003.008 - OS Credential Dumping: /etc/passwd, /etc/master.passwd and /etc/shadow==

#### References to use while conducting
- [ ] ADD
- [x] REFERENCE
**https://www.atomicredteam.io/atomic-red-team/atomics/T1003.008#atomic-test-4---access-etcshadowpasswdmasterpasswd-with-a-standard-bin-thats-not-cat**
---
### Experiment #3
==T1222.002 - File and Directory Permissions Modification: FreeBSD, Linux and Mac File and Directory Permissions Modification==

#### References to use while conducting
- [ ] ADD
- [x] REFERENCE
**https://github.com/redcanaryco/atomic-red-team/blob/master/atomics/T1222.002/T1222.002.md**